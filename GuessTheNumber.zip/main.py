import random

print("Welcome to the Number Guessing Game!")
print("I'm thinking of a number between 1 and 100.")
difficulty = input("Choose a difficulty. Type 'easy' or 'hard':")
difficulty = difficulty.lower()
while difficulty != 'easy' and difficulty != 'hard':
  difficulty = input("Please type 'easy' or 'hard': ")
  difficulty = difficulty.lower()

if difficulty == 'easy':
  chances = 10
elif difficulty == 'hard':
  chances = 5

print(f"You have {chances} attempts remaining to guess the number.")


number = random.randint(1, 101)

guess = int(input("\nMake a guess: "))

while guess != number and chances > 1:
  if guess > number:
    print("too high")
  elif guess < number:
    print("too low")
  chances -= 1
  print(f"You have {chances} attempts remaining to guess the number.")
  guess = int(input("Make a guess: "))

if chances >= 1:
  print(f"You got it! The answer was {number}.")